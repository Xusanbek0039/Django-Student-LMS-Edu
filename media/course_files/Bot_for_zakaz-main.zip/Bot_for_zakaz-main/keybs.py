from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

kb = InlineKeyboardMarkup().add( InlineKeyboardButton('Заполнить заявку', callback_data='start'))



