import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BehaviorManagerPage } from './behavior-manager.page';

const routes: Routes = [
  {
    path: '',
    component: BehaviorManagerPage,
    children: [
      {
        path: 'landing',
        children: [
          {
            path: '',
            loadChildren: () => import('./main-user-events/main-user-events.module').then( m => m.MainUserEventsPageModule)
          },
          {
            path: 'main-store-events',
            loadChildren: () => import('./main-store-events/main-store-events.module').then( m => m.MainStoreEventsPageModule)
          },
          {
            path: 'main-user-entourage',
            loadChildren: () => import('./main-user-entourage/main-user-entourage.module').then( m => m.MainUserEntouragePageModule)
          },
          {
            path: 'main-user-profile',
            loadChildren: () => import('./main-user-profile/main-user-profile.module').then( m => m.MainUserProfilePageModule)
          },
          {
            path: 'main-user-activity',
            loadChildren: () => import('./main-user-activity/main-user-activity.module').then( m => m.MainUserActivityPageModule)
          },
        ]
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BehaviorManagerPageRoutingModule {}
