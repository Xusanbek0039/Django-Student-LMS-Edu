import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { BehaviorManagerPageRoutingModule } from './behavior-manager-routing.module';

import { BehaviorManagerPage } from './behavior-manager.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    BehaviorManagerPageRoutingModule
  ],
  declarations: [BehaviorManagerPage]
})
export class BehaviorManagerPageModule {}
