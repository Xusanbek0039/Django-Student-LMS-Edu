import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-behavior-manager',
  templateUrl: './behavior-manager.page.html',
  styleUrls: ['./behavior-manager.page.scss'],
})
export class BehaviorManagerPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
