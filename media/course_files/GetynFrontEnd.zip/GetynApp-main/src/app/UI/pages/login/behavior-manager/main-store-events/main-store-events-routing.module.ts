import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MainStoreEventsPage } from './main-store-events.page';

const routes: Routes = [
  {
    path: '',
    component: MainStoreEventsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MainStoreEventsPageRoutingModule {}
