import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MainStoreEventsPageRoutingModule } from './main-store-events-routing.module';

import { MainStoreEventsPage } from './main-store-events.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MainStoreEventsPageRoutingModule
  ],
  declarations: [MainStoreEventsPage]
})
export class MainStoreEventsPageModule {}
