import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-store-events',
  templateUrl: './main-store-events.page.html',
  styleUrls: ['./main-store-events.page.scss'],
})
export class MainStoreEventsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
