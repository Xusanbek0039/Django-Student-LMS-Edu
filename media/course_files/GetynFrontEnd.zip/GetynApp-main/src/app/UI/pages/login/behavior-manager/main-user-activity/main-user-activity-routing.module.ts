import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MainUserActivityPage } from './main-user-activity.page';

const routes: Routes = [
  {
    path: '',
    component: MainUserActivityPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MainUserActivityPageRoutingModule {}
