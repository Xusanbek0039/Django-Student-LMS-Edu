import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MainUserActivityPageRoutingModule } from './main-user-activity-routing.module';

import { MainUserActivityPage } from './main-user-activity.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MainUserActivityPageRoutingModule
  ],
  declarations: [MainUserActivityPage]
})
export class MainUserActivityPageModule {}
