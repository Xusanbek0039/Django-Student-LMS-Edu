import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-user-activity',
  templateUrl: './main-user-activity.page.html',
  styleUrls: ['./main-user-activity.page.scss'],
})
export class MainUserActivityPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
