import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MainUserEntouragePage } from './main-user-entourage.page';

const routes: Routes = [
  {
    path: '',
    component: MainUserEntouragePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MainUserEntouragePageRoutingModule {}
