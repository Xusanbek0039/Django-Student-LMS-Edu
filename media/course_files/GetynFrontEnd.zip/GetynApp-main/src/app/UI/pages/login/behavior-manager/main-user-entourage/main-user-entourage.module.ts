import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MainUserEntouragePageRoutingModule } from './main-user-entourage-routing.module';

import { MainUserEntouragePage } from './main-user-entourage.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MainUserEntouragePageRoutingModule
  ],
  declarations: [MainUserEntouragePage]
})
export class MainUserEntouragePageModule {}
