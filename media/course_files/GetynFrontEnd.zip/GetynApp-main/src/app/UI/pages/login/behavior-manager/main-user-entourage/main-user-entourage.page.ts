import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-user-entourage',
  templateUrl: './main-user-entourage.page.html',
  styleUrls: ['./main-user-entourage.page.scss'],
})
export class MainUserEntouragePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
