import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';

import { EventComponent } from './event/event.component';
import { EventsComponent } from './events/events.component';

@NgModule({
  declarations: [
    EventComponent,
    EventsComponent
  ],
  exports:[
    EventComponent,
    EventsComponent
  ],
  imports: [
    CommonModule,
    IonicModule
  ]
})
export class ComponentModule { }
