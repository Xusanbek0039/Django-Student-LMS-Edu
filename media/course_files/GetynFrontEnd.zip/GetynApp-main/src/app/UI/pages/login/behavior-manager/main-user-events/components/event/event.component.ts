import { Component, Input, OnInit } from '@angular/core';
import { IEvento } from 'src/app/domain/interfaces/IEventos';

@Component({
  selector: 'app-event',
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.scss'],
})
export class EventComponent implements OnInit {

  @Input() event: IEvento = {};

  constructor() { }

  ngOnInit() {}

}
