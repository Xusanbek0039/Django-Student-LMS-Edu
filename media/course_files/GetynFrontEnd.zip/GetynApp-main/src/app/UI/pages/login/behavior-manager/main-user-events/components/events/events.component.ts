import { Component, Input, OnInit } from '@angular/core';
import { IEvento } from 'src/app/domain/interfaces/IEventos';

@Component({
  selector: 'app-events',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.scss'],
})
export class EventsComponent implements OnInit {

  @Input() events: IEvento[] = [];

  constructor() { }

  ngOnInit() {}

}
