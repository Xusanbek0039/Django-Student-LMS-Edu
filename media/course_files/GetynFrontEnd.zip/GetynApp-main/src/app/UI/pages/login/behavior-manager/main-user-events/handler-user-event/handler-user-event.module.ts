import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { HandlerUserEventPageRoutingModule } from './handler-user-event-routing.module';

import { HandlerUserEventPage } from './handler-user-event.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    HandlerUserEventPageRoutingModule
  ],
  declarations: [HandlerUserEventPage]
})
export class HandlerUserEventPageModule {}
