import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-handler-user-event',
  templateUrl: './handler-user-event.page.html',
  styleUrls: ['./handler-user-event.page.scss'],
})
export class HandlerUserEventPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
