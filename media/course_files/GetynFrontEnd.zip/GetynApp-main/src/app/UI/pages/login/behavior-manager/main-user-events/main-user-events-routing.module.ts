import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MainUserEventsPage } from './main-user-events.page';

const routes: Routes = [
  {
    path: '',
    component: MainUserEventsPage
  },
  {
    path: 'handler-user-event',
    loadChildren: () => import('./handler-user-event/handler-user-event.module').then( m => m.HandlerUserEventPageModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MainUserEventsPageRoutingModule {}
