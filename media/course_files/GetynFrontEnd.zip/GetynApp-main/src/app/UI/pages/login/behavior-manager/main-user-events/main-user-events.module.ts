import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ComponentModule } from './components/component.module';
import { MainUserEventsPageRoutingModule } from './main-user-events-routing.module';
import { MainUserEventsPage } from './main-user-events.page';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MainUserEventsPageRoutingModule,
    ComponentModule
  ],
  declarations: [MainUserEventsPage]
})
export class MainUserEventsPageModule {}
