import { Component, OnInit } from '@angular/core';
import { urlApiEvent } from 'src/app/domain/common/endpoints';
import { HandlerService } from 'src/app/infraestructure/services/handler.service';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { Storage } from '@ionic/storage-angular';
import { TakeSkip } from '../../../../../domain/models/takeSkip';
import { AlertMessageService } from 'src/app/infraestructure/services/alert-message.service';
import { IEvento } from 'src/app/domain/interfaces/IEventos';

const apiURL = environment.apiEvent;
const eventGetAll = urlApiEvent.eventGetAll;

@Component({
  selector: 'app-main-user-events',
  templateUrl: './main-user-events.page.html',
  styleUrls: ['./main-user-events.page.scss'],
})
export class MainUserEventsPage implements OnInit {

  loading = false;
  token: string;
  events: IEvento[] = [];
  habilitado = true;

  constructor(
    private storage: Storage,
    private handlerService: HandlerService,
    private alertMessageService: AlertMessageService
              ) { }

  ngOnInit() {
    this.getEvents();
  }

  async getEvents(event?, pull: boolean = false, skipRefresh?: number) {
    this.loading = true;
    await this.guardarToken().then(x =>{
      this.token = x;
      console.log(this.token);
    });
    const take = 4;
    let skip: number;
    if(skipRefresh){
      skip = skipRefresh;
    }else{
      skip = 0;
    }
    const takeSkip: TakeSkip = new TakeSkip(take,skip);
    this.handlerService.getAll(apiURL,eventGetAll,takeSkip,this.token).subscribe(y => {
      // this.events = y.data as IEvento[];
      if(!pull){
        this.events.push( ...y.data );
      }
      if(pull){
        const takeSkip2: TakeSkip = new TakeSkip(take,skip+4);
        this.handlerService.getAll(apiURL,eventGetAll,takeSkip2,this.token).subscribe(w =>{
          this.events.push( ...y.data );
        });
        // this.events = [];
        // this.habilitado = false;
      }
      if( event ){
        event.target.complete();
        if(y.data.length === 0){
          this.habilitado = false;
        }
      }
      console.log(y);
      this.loading = false;
    }, error =>{
      console.log(error);
      this.loading = false;
      this.alertMessageService.presentAlert('Error en carga de datos.');
    });
  }

  async guardarToken(){
    // this.storage.create();
    return await this.storage.get('token');
  }

  doRefresh(event){
    this.getEvents(event,false);
  }
}
