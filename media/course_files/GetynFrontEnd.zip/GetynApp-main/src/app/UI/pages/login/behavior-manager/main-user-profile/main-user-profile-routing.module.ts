import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MainUserProfilePage } from './main-user-profile.page';

const routes: Routes = [
  {
    path: '',
    component: MainUserProfilePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MainUserProfilePageRoutingModule {}
