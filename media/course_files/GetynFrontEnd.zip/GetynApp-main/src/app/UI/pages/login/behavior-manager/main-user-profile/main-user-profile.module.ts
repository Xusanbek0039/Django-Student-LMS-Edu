import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MainUserProfilePageRoutingModule } from './main-user-profile-routing.module';

import { MainUserProfilePage } from './main-user-profile.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MainUserProfilePageRoutingModule
  ],
  declarations: [MainUserProfilePage]
})
export class MainUserProfilePageModule {}
