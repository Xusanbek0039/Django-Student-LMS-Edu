import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-user-profile',
  templateUrl: './main-user-profile.page.html',
  styleUrls: ['./main-user-profile.page.scss'],
})
export class MainUserProfilePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
