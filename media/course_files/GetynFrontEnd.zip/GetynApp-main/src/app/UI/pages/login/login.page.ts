import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { IonSlides, NavController } from '@ionic/angular';
import { Storage } from '@ionic/storage-angular';
import { urlApiAuth } from 'src/app/domain/common/endpoints';
import { AlertMessageService } from 'src/app/infraestructure/services/alert-message.service';
import { HandlerService } from 'src/app/infraestructure/services/handler.service';
import { environment } from 'src/environments/environment';
import { User } from '../../../domain/models/user';

const apiURL = environment.apiAuth;
const authGetToken = urlApiAuth.authGetToken;

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  @ViewChild('slidePrincipal', {static: true}) slides: IonSlides;

  loginUser = {
    username: 'marian',
    password: 'marian123'
  };

  token: string = null;
  expireDate: Date = null;
  loading = false;

  constructor(
    private storage: Storage,
    private navCtrl: NavController,
    private handlerService: HandlerService,
    private alertMessageService: AlertMessageService
  ) { }

  ngOnInit() {
    this.slides.lockSwipes(true);
  }

  async login( fLogin: NgForm ){

    const username = this.loginUser.username;
    const password = this.loginUser.password;

    const user: User = new User(username,password);

    if( fLogin.invalid) { return;}
    this.loading=true;
    this.handlerService.getWithDataWithoutToken(apiURL,authGetToken,user).subscribe(async data => {
      await this.guardarToken(data.token.token, data.token.expireDate);
      this.loading = false;
      this.navCtrl.navigateRoot('login/behavior-manager/landing', {animated: false});
    }, error =>{
      console.log(error);
      this.loading = false;
      this.token = null;
      this.storage.create();
      this.storage.clear();
      this.alertMessageService.presentAlert('Usuario o Contraseña incorrectos.');
    });

  }

  viewLogin(){
    this.slides.lockSwipes(false);
    this.slides.slideTo(0);
    this.slides.lockSwipes(true);
  }
  viewSignUp(){
    this.slides.lockSwipes(false);
    this.slides.slideTo(1);
    this.slides.lockSwipes(true);
  }

  async guardarToken( token: string, expireDate: Date){
    this.token = token;
    this.expireDate = expireDate;
    this.storage.create();
    await this.storage.set('token',token);
    await this.storage.set('expireDate',expireDate);
  }
}
