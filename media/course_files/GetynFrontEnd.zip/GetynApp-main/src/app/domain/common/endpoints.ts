export const urlApiAuth = {
  //POST
  authGetToken: '/Auth/GetToken',
  //POST
  authValidateToken: '/Auth/ValidateToken',
  //GET
  rolGetById: '/Rol/GetById',
  //POST
  rolGetAll: '/Rol/GetAll',
  //POST
  rolGetByFilter: '/Rol/GetByFilter',
  //POST
  rolCreate: '/Rol/Create',
  //PUT
  rolUpdate: '/Rol/Update',
  //DELETE
  rolDelete: '/Rol/Delete',
  //POST
  rolCount: '/Rol/Count',
  //GET
  userGetCompleteById: '/User/GetCompleteById',
};

export const urlApiEvent= {
  //GET
  eventGetById: '/Event/GetById',
  //POST
  eventGetAll: '/Event/GetAll',
  //POST
  eventCount: '/Event/Count',
  //POST
  eventCountBySections: '/Event/CountBySections',
  //POST
  eventCreate: '/Event/Create',
  //PUT
  eventUpdate: '/Event/Update',
  //DELETE
  eventDelete: '/Event/Delete'
};
