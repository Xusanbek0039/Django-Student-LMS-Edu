export interface IEventos {
  count:   number;
  message: string;
  data:    IEvento[];
}

export interface IEvento {
  title?:              string;
  description?:        string;
  expirationDate?:     Date;
  minAge?:             number;
  maxAge?:             number;
  minParticipants?:    number;
  maxParticipants?:    number;
  mainImageURL?:       string;
  tags?:               string;
  userCreatorId?:      number;
  userCreator?:        null;
  categoryId?:         number;
  category?:           null;
  groupsParticipants?: any[];
  usersParticipants?:  any[];
  id?:                 string;
  addedDate?:          Date;
  modifiedDate?:       null;
  disabledDate?:       null;
}
