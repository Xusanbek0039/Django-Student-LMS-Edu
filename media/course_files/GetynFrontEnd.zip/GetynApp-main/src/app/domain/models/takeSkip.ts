/* eslint-disable @typescript-eslint/naming-convention */
export class TakeSkip{
  take: number;
  skip: number;

  constructor( take: number,
               skip: number)
               {
                this.take = take;
                this.skip = skip;
              }
}
