export class TokenAuth{

  userId: string;
  firstName: string;
  lastName: string;
  username: string;
  email: string;
  token: Token;

}

class Token {
  claims: Claims<string> = {};
  expireDate: Date;
  token: string;
}

interface Claims<T> {
  [Key: string]: T;
}
