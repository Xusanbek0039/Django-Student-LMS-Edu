/* eslint-disable quote-props */
/* eslint-disable @typescript-eslint/naming-convention */
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

// const urlApi = environment.apiAuth;
// const authGetToken = urlApiAuth.authGetToken;

@Injectable({
  providedIn: 'root'
})
export class HandlerService {

  constructor(private http: HttpClient) { }

  // getToken(data: User): Observable<any>{
  //   return this.http.post(urlApiAuth+authGetToken,data);
  // }

  /**Definiones de tipos
   * @param uT Url de API
   * @param eT Endpoint de API
   * @param dT DTO
   * @behavior Cada metodo imita un endpoint generico.
   */

  getWithDataWithoutToken(uT: string,eT: string,dT: any): Observable<any>{
    return this.http.post(uT+eT,dT);
  }

  getWithDataWithToken(uT: string,eT: string,dT: any,token: any): Observable<any>{
    const tokenAuth =  token;
    const headers = {
      'accept': 'text/plain',
      'Authorization': 'Bearer '+tokenAuth,
      'Content-Type': 'application/json'
    };
    return this.http.post(uT+eT,dT,{headers});
  }

  getAll(uT: string,eT: string,dT: any,token: any): Observable<any>{
    const tokenAuth =  token;
    const headers = {
      'accept': 'text/plain',
      'Authorization': 'Bearer '+tokenAuth,
      'Content-Type': 'application/json'
    };
    return this.http.post(uT+eT,dT,{headers});
  }

  getById(uT: string,eT: string,dT: any,token: any): Observable<any>{
    const tokenAuth =  token;
    const headers = {
      'accept': 'text/plain',
      'Authorization': 'Bearer '+tokenAuth,
      'Content-Type': 'application/json'
    };
    return this.http.get(uT+eT+dT,{headers});
  }

  update(uT: string,eT: string,dT: any,token: any): Observable<any>{
    const tokenAuth =  token;
    const headers = {
      'accept': 'text/plain',
      'Authorization': 'Bearer '+tokenAuth,
      'Content-Type': 'application/json'
    };
    return this.http.put(uT+eT,dT,{headers});
  }

  delete(uT: string,eT: string,dT: any,token: any): Observable<any>{
    const tokenAuth =  token;
    const headers = {
      'accept': 'text/plain',
      'Authorization': 'Bearer '+tokenAuth,
      'Content-Type': 'application/json'
    };
    return this.http.delete(uT+eT+dT,{headers});
  }
}


