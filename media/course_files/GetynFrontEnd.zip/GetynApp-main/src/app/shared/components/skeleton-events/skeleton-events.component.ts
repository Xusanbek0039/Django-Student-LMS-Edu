import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-skeleton-events',
  templateUrl: './skeleton-events.component.html',
  styleUrls: ['./skeleton-events.component.scss'],
})
export class SkeletonEventsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
