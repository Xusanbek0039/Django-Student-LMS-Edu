import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-skeleton-store-event',
  templateUrl: './skeleton-store-event.component.html',
  styleUrls: ['./skeleton-store-event.component.scss'],
})
export class SkeletonStoreEventComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
