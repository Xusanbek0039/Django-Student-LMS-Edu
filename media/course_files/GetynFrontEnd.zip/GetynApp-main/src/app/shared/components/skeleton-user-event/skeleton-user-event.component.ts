import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-skeleton-user-event',
  templateUrl: './skeleton-user-event.component.html',
  styleUrls: ['./skeleton-user-event.component.scss'],
})
export class SkeletonUserEventComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
