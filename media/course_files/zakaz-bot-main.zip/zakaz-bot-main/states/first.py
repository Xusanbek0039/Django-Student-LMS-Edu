from aiogram.dispatcher.filters.state import State,StatesGroup

class First(StatesGroup):
    ism = State()
    Telefon = State()
    dopalnitelniy = State()
    qayer = State()